<?php
include "connection.php";
$user=$_REQUEST['user'];
$pass=$_REQUEST['pass'];
if(isset($_REQUEST['register'])){
$sql="insert into registration(`id`,`username`,`password`)values('','$user','$pass')";
$res=mysqli_query($con,$sql);
if($res){
	echo "<script>alert('Registration Sucessfull')</script>";
	echo "<script>window.location.href='/PHPPROJECT1/userlogin.php'</script>";
}
else{
	echo "<script>alert('Registration Unsucessfull')</script>";
	echo "<script>window.location.href='/PHPPROJECT1/registration.php'</script>";
}
}
