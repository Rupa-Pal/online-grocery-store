<html>
<head>
<P><center><b><h1 style="color:#F7361C">ＧＲＯＣＥＲＹ ＣＡＲＴ</h1></b></center></p>
</head>
<body>
  <div>
       <center>
    <h1>Admin Login</h1>
    <form action="/PHPPROJECT1/adminaction.php"  method="post">
    
     Admin Name:<input type="text" name="user" required><br><br>
   
      Password:<input type="password"name="pass" required></br><br>
	<input type="submit" name="login" value="Login"><br></br>
	
    
</form>
</center>
</div>
</body>
</html>