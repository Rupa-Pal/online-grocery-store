<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>logaction</title>
</head>
<body>
</body>
</html>
<?php
  include "connection.php";
  error_reporting(0);
   $user=$_REQUEST['user'];
   $pass=$_REQUEST['pass'];
   if(isset($_REQUEST['login']))
   {
   	$sql="select * from userlogin where user_name='$user'and password=$pass";
   	$result=mysqli_query($con,$sql);
   	if($result)
   	{
   		echo'<script>alert("log in sucessfull")</script>';
   		
   	}
   	else
   	{
   		echo'<script>alert("there is some problem")</script>';
   		
     }
   }
?> 